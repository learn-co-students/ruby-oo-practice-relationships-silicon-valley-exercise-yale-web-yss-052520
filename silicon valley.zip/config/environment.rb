#equire 'bundler/setup'
# Bundler.require

require 'pry'
require 'require_all'

require_rel '../app'